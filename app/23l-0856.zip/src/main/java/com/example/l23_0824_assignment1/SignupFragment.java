package com.example.l23_0824_assignment1;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.google.android.material.textfield.TextInputEditText;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link SignupFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class SignupFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public SignupFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment SignupFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static SignupFragment newInstance(String param1, String param2) {
        SignupFragment fragment = new SignupFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_signup, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextInputEditText etEmailSignUp = view.findViewById(R.id.etEmailSignUp);
        TextInputEditText etPasswordSignUp = view.findViewById(R.id.etPasswordSignUp);
        TextInputEditText etVerify_PasswordSignUp = view.findViewById(R.id.etVerify_PasswordSignUp);
        Button btnSignup = view.findViewById(R.id.btnSignup);

        SharedPreferences sp = requireContext().getSharedPreferences("login", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();

        btnSignup.setOnClickListener((v) -> {
            String email           = etEmailSignUp.getText().toString().trim();
            String password        = etPasswordSignUp.getText().toString().trim();
            String verifyPassword  = etVerify_PasswordSignUp.getText().toString().trim();

            if(email.isEmpty())
            {
                etEmailSignUp.setError("Email is required");
                return;
            }

            if(password.isEmpty()) {
                etPasswordSignUp.setError("Password is required");
                return;
            }
            if(verifyPassword.isEmpty()) {
                etVerify_PasswordSignUp.setError("Password is required");
                return;
            }
            if(!password.equals(verifyPassword)) {
                etVerify_PasswordSignUp.setError("Passwords do not match");
                return;
            }
            if(!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                etEmailSignUp.setError("Enter a valid email");
                return;
            }
            if(password.length() < 8) {
                etPasswordSignUp.setError("Password must be at least 8 characters long");
                return;
            }

            if(!password.matches(".*[A-Z].*")) {
                etPasswordSignUp.setError("Password must contain at least one uppercase letter");
                return;
            }
            if(!password.matches(".*[a-z].*")) {
                etPasswordSignUp.setError("Password must contain at least one lowercase letter");
                return;
            }
            if(!password.matches(".*[0-9].*")) {
                etPasswordSignUp.setError("Password must contain at least one number");
                return;
            }

            editor.putString("email", email);
            editor.putString("password", password);
            editor.putBoolean("isLogin", true);
            editor.commit();

            Intent intent = new Intent(getActivity(), MainActivity.class);
            startActivity(intent);
            getActivity().finish();



        });


    }
}